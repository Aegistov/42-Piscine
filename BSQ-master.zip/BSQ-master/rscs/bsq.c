/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bsq.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ddelgado <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/02 23:28:19 by ddelgado          #+#    #+#             */
/*   Updated: 2016/08/02 23:28:21 by ddelgado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

char	*square_param(char *ptr, int w, int *map, int s)
{
	int		i;
	int		sqh;
	int		t;
	int		h;
	char	*str;

	str = NULL;
	str = mallocate(ptr, str);
	i = -1;
	sqh = map[s];
	t = s + sqh;
	h = s - 1;
	while (++i < sqh)
	{
		while (++h < t)
		{
			if (ptr[h] == g_free_space)
				str[h] = g_square;
		}
		s = s + w + 1;
		h = s - 1;
		t = s + sqh;
	}
	return (str);
}

void	width_height_calc(int *max, int width, int height, int p_start)
{
	*max = (((width * height - width + (height - 1)) + (width - 1))) + (p_start);
}

/*Leave this printf to see final output in SQUARE_PARAM
	int		z = 0;
	printf("\n");
	while (str[z] != '\0')
	{
		printf("%c", str[z]);
		z++;
	}
	end of print function ^^^^*/
