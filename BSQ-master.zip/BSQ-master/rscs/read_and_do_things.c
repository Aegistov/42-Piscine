/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   do_things.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ddelgado <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/28 18:08:53 by ddelgado          #+#    #+#             */
/*   Updated: 2016/07/28 18:08:54 by ddelgado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

char	g_obstacle;
char	g_free_space;
char	g_square;
int		g_height;

void	change_global_variables(char *str)
{
	int i;
	int counter;

	i = 0;
	counter = 0;
	while (str[i] != '\0')
	{
		if ((g_height = ft_atoi(str)) > 0 && counter == 0)
		{
			counter++;
			while (str[i] >= '0' && str[i] <= '9')
				i++;
			g_free_space = str[i];
			i++;
			g_obstacle = str[i];
			i++;
			g_square = str[i];
		}
		i++;
	}
}

int		do_the_holder(char c[1], int *counter)
{
	if (c[0] == '\n' && *counter == 0)
	{
		*counter += 1;
		return (1);
	}
	else if (c[0] != '\n' && *counter == 0)
	{
		return (1);
	}
	else
		return (0);
}

char	*check_first_line(char *input, int fd, int ret)
{
	int		i;
	int		j;
	char	buf[1];
	char	holder[1000];

	j = 0;
	i = 0;
	while (ret == 1)
	{
		ret = read(fd, &buf, 1);
		if (ret == 1)
		{
			input[j] = buf[0];
			j++;
		}
		i++;
	}
	input[j] = '\0';
	change_global_variables(holder);
	return (input);
}

char	*read_file(int fd, int *ecode, char *argv, char *input)
{
	int		ret;

	ret = 1;
	input = check_first_line(input, fd, ret);
	if (fd == -1)
	{
		error_message(argv, ecode);
		return (0);
	}
	else
		return (input);
}

char	*array_read(char *argv, char *input)
{
	int	fd;
	int	ecode;

	open_file(argv, &fd, &ecode);
	if (fd != -1)
		input = read_file(fd, &ecode, argv, input);
	if (fd != -1)
		close_file(&fd, argv, &ecode);
	if (fd != -1)
		return (input);
	else
		return (0);
}
