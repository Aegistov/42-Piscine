
#include "bsq.h"

void	pipe_and_do_things(char *str)
{
	int	p_start;
	int	width;
	int size;
	int *num_field;
	int max;

	width = 0;
	p_start = 0;
	p_start = global_vars(str);
	size = ft_strlen(&str[p_start]);
	while (str[p_start] != '\n')
	{
		width++;
		p_start++;
	}
	p_start -= width;
	width_height_calc(&max, width, g_height, p_start);
	num_field = (int*)malloc(sizeof(int) * size);
	*num_field = ctoi(str, max, num_field, p_start);
	*num_field = possibility_map(num_field, max, width, p_start);
	get_the_square(str, num_field, max, width);
}

int		global_vars(char *str)
{
	int		i;
	int		som;

	i = 0;
	som = 0;
	while (str[i] != '\n')
	{
		g_height = ft_atoi(str);
		if (str[i] < '0' || str[i] > '9')
		{
			g_free_space = str[i];
			g_obstacle = str[i + 1];
			g_square = str[i + 2];
			return (i + 4);
		}
		i++;
	}
	return (*str);
}