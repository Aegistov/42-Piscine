/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ctoi.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ddelgado <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/02 23:28:39 by ddelgado          #+#    #+#             */
/*   Updated: 2016/08/02 23:28:41 by ddelgado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int		possibility_map(int *map, int max, int w, int p_start)
{
	int		start;
	int		min;

	start = max - w - 1;
	while (start >= p_start)
	{
		if (map[start] == '\n')
		{
			map[start] = '\n';
			start--;
		}
		if (map[start] == 0)
			map[start] = 0;
		else if (map[start + 1] == '\n')
			map[start] = 1;
		else
		{
			min = min_compare(map[start + (w + 1)], map[start + (w + 2)]);
			map[start] += min_compare(map[start + 1], min);
		}
		start--;
	}
	return (*map);
}

int		ctoi(char *ptr, int max, int *map, int p_start)
{
	int		i;
	
	i = max;
	while (i >= p_start)
	{
		if (ptr[i] == g_obstacle)
			map[i] = 0;
		else if (ptr[i] == g_free_space || ptr[i] == g_square)
			map[i] = 1;
		else if (ptr[i] == '\n')
			map[i] = '\n';
		i--;
	}
	return (*map);
}

/* print function for 1's and 0's in CTOI
int		h;

	h = p_start;
	while (h <= max)
	{
		if (map[h] == '\n')
		{
			printf("%c", map[h]);
		}
		else
			printf("%d", map[h]);
		h++;
	}
	*/