/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ddelgado <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/02 23:28:48 by ddelgado          #+#    #+#             */
/*   Updated: 2016/08/02 23:28:49 by ddelgado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

char	*init_char(char *input, char *argv, int size)
{
	input = (char*)malloc(sizeof(char) * (size + 1));
	input = array_read(argv, input);
	return (input);
}

void	get_the_square(char *input, int *num_field, int max, int width)
{
	int		bsq;
	char	*nstr;

	bsq = bsq_loc(num_field, max);
	nstr = square_param(input, width, num_field, bsq);
	ft_putstr(nstr, 1);
}

void	read_and_do_things(char *argv)
{
	int		width;
	int		size;
	char	*input;
	int		*num_field;
	int		max;

	width = 0;
	input = NULL;
	num_field = NULL;
	max = 0;
	size = first_read(argv, &width);
	if (size > 0)
	{
		input = init_char(input, argv, size);
		if (input != NULL)
			pipe_and_do_things(input);
	}
}

int		main(int argc, char **argv)
{
	int		i;
	char	*str;

	str = NULL;
	if (argc > 1)
	{
		i = 1;
		while (i < argc)
		{
			read_and_do_things(argv[i]);
			i++;
		}
	}
	else if (argc == 1)
	{
		str = ft_input();
		pipe_and_do_things(str);
	}
	else
	{
		ft_putstr("error", 1);
	}
	return (0);
}
