/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   auxillaryTwo.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcapling <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/03 22:24:03 by jcapling          #+#    #+#             */
/*   Updated: 2016/08/03 22:24:04 by jcapling         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"
#include "ft_error_codes.h"

int		bsq_loc(int *map, int max)
{
	int		i;
	int		num;
	int		index;

	i = 0;
	num = map[i];
	index = i;
	while (i < (max + 1))
	{
		if (map[i] == '\n')
			i++;
		else if (map[i] > num)
		{
			num = map[i];
			index = i;
			i++;
		}
		else
			i++;
	}
	return (index);
}

void	error_message(char *argv, int *ecode)
{
	ft_putstr("bsq: ", 1);
	ft_putstr(argv, 1);
	ft_putstr(": ", 1);
	ft_putstr(g_errtable[*ecode], 2);
	ft_putstr("\n", 1);
}

void	open_file(char *argv, int *fd, int *ecode)
{
	*fd = open(argv, O_RDWR);
	*ecode = errno;
	if (*fd == -1)
		error_message(argv, ecode);
}

void	close_file(int *fd, char *argv, int *ecode)
{
	*fd = close(*fd);
	if (*fd == -1)
		error_message(argv, ecode);
}

int		ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}
