/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_first.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcapling <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/03 22:08:05 by jcapling          #+#    #+#             */
/*   Updated: 2016/08/03 22:08:06 by jcapling         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	check_er_give_numb(int *size, int *counter, int *width, char c)
{
	if (c != '\n' && *counter == 0)
		*size += 1;
	else if (c == '\n' && *counter == 0)
	{
		*counter += 1;
		*size += 1;
	}
	else if (c != '\n' && *counter == 1)
	{
		*size += 1;
		*width += 1;
	}
	else if (c == '\n' && *counter == 1)
	{
		*counter += 1;
		*size += 1;
	}
	else if (c == '\n' && *counter == 2)
		*size += 1;
	else if (c != '\n' && *counter == 2)
		*size += 1;
}

int		check_errors(int fd, int *ecode, char *argv, int size)
{
	if (fd == -1)
	{
		error_message(argv, ecode);
		return (0);
	}
	else if (size == 0)
		return (0);
	else
		return (size);
}

int		read_file_first(int fd, int *ecode, char *argv, int *width)
{
	int		ret;
	int		size;
	char	buf[1];
	int		counter;
	char	holder;

	ret = 1;
	size = 0;
	counter = 0;
	while (ret == 1)
	{
		ret = read(fd, &buf, 1);
		if (ret == 1)
		{
			holder = buf[0];
			check_er_give_numb(&size, &counter, width, holder);
		}
	}
	return (check_errors(fd, ecode, argv, size));
}

int		first_read(char *argv, int *width)
{
	int	fd;
	int	ecode;
	int size;

	open_file(argv, &fd, &ecode);
	if (fd != -1)
		size = read_file_first(fd, &ecode, argv, width);
	if (fd != -1)
		close_file(&fd, argv, &ecode);
	if (fd != -1)
		return (size);
	else
		return (0);
}
