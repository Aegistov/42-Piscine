/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   auxillary.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ddelgado <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/02 23:28:10 by ddelgado          #+#    #+#             */
/*   Updated: 2016/08/02 23:28:12 by ddelgado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int		check_number(char c)
{
	if (c >= '0' && c <= '9')
		return (1);
	else
		return (0);
}

void	ft_putchar(char c, int fd)
{
	write(fd, &c, 1);
}

void	ft_putstr(char *str, int fd)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		ft_putchar(str[i], fd);
		i++;
	}
}

int		min_compare(int n1, int n2)
{
	if (n1 < n2)
		return (n1);
	else
		return (n2);
}

char	*mallocate(char *src, char *dest)
{
	int i;

	i = 0;
	dest = (char*)malloc(sizeof(char) * ft_strlen(src));
	if (dest != NULL)
		while (src[i] != '\0')
		{
			dest[i] = src[i];
			i++;
		}
	dest[i] = '\0';
	return (dest);
}
