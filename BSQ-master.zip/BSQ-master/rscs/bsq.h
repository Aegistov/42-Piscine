/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bsq.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ddelgado <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/02 23:28:30 by ddelgado          #+#    #+#             */
/*   Updated: 2016/08/02 23:28:32 by ddelgado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef BSQ_H

# define BSQ_H

# include <unistd.h>
# include <stdlib.h>
# include <sys/types.h>
# include <fcntl.h>
# include <sys/stat.h>
# include <stdio.h>

extern	char	g_obstacle;
extern	char	g_free_space;
extern	char	g_square;
extern	int		g_height;
extern	int		g_size;

typedef struct		s_link
{
	struct s_link	*next;
	char			data;
	char			str[200];
}					t_link;

void				get_the_square(char *input, int *num_field, int max, int width);
void				ft_convert(char *str, t_link *begin_list);
char				*ft_input(void);
t_link				*ft_push(char *str, t_link *buff);
t_link				*ft_create(char *str);
void				width_height_calc(int *max, int width, int height, int p_start);
int					ctoi(char *ptr, int max, int *map, int width);
int					possibility_map(int	*map, int i, int w, int p_start);
int					bsq_loc(int *map, int max);
int					first_read(char *argv, int *width);
char				*square_param(char *ptr, int w, int *map, int s);
void				ft_putchar(char c, int fd);
void				ft_putstr(char *str, int fd);
int					min_compare(int n1, int n2);
char				*mallocate(char *src, char *dest);
char				*array_read(char *argv, char *input);
void				error_message(char *argv, int *ecode);
char				ft_stdin(void);
int					check_number(char c);
int					ft_atoi(char *str);
void				open_file(char *argv, int *fd, int *ecode);
void				close_file(int *fd, char *argv, int *ecode);
void				error_message(char *argv, int *ecode);
int					ft_strlen(char *str);
void				pipe_and_do_things(char *str);
int					global_vars(char *str);

#endif
